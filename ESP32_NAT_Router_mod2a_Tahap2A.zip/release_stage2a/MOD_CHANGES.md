# Modifikasi di atas firmware Martin (esp32_nat_router v2.4.23)

Basis: https://github.com/martin-ger/esp32_nat_router commit 08da293 (v2.4.23).
Semua perubahan di file asli ditandai komentar `[MOD]`. Tidak ada fitur asli yang dihapus.

## Tahap 1 – Fondasi (v2.4.23-mod.1)

### File baru
- `include/event_log.h`, `main/event_log.c` – log event ring buffer 48 entri di RAM.
- `include/sys_health.h`, `main/sys_health.c` – sampling tiap 10 s: RAM (bebas, internal, minimum, blok terbesar, fragmentasi), beban CPU per core (FreeRTOS run-time stats), suhu die (sensor lama ESP32, hanya ditampilkan kalau terbukti valid), alasan reset termasuk alasan restart software yang disimpan di RTC RAM, histori 60 sampel (10 menit).
- `components/http_server/dash_api.c`, `http_internal.h` – halaman `/dash` dan API JSON `/api/session|login|logout|password|status|health|log|reboot|settings`.
- `components/http_server/www/dash.html` – dashboard baru (bahasa Indonesia), di-gzip saat build oleh `www/gzip_page.py`.
- `tools/dash_test/` – server mock + tes Playwright untuk semua tombol dashboard.

### Perubahan di file asli
- `cmd_router.c`: hash password admin jadi PBKDF2-HMAC-SHA256 10.000 iterasi (`$p2$...`). Format lama Martin (`salt:hash`) dan plaintext tetap diterima, dan dimigrasi otomatis saat login berhasil.
- `http_server.c`: pembatas percobaan login per IP (5 gagal → blokir 60 s, naik dua kali lipat sampai 15 menit) untuk login klasik dan /dash; `max_uri_handlers` +10; registrasi API dashboard; wrapper sesi/CSRF; reboot halaman klasik mencatat alasan.
- `esp32_nat_router.c`: `sys_health_init()` setelah NVS; event log untuk uplink putus/tersambung, client masuk/keluar; restart factory-reset dan watchdog mencatat alasan.
- `main/CMakeLists.txt`, `components/http_server/CMakeLists.txt`: file baru dan embed dashboard.
- `sdkconfig.defaults`: `CONFIG_FREERTOS_GENERATE_RUN_TIME_STATS=y`, `CONFIG_ESP_TIMER_TASK_STACK_SIZE=4096`.
- `CMakeLists.txt`: versi `2.4.23-mod.1`.

### Dampak ukuran (dibanding build asli dengan toolchain yang sama)
- App: 1.389.216 B (asli 1.371.504 B), sisa slot OTA 12%.
- IRAM: +108 B (88,8% terpakai). DRAM statis: +5,7 KB.

### Keterbatasan yang diketahui
- Sesi login tetap satu sesi (desain Martin); login di /dash menimpa sesi halaman klasik dan sebaliknya.
- Setelah password dimigrasi ke PBKDF2, firmware asli Martin tidak bisa memverifikasinya.
- Kalau password admin belum dibuat, siapa pun yang tersambung ke AP bisa membuatnya (sama seperti perilaku asli).
- Sensor suhu ESP32 klasik tidak terdokumentasi; di banyak chip nilainya macet di 128 °F, dan dashboard akan menampilkan "Tidak tersedia".

## Tahap 2A – Monitoring (v2.4.23-mod.2a)

Cakupan: hanya monitoring. Tidak ada perubahan di konfigurasi WiFi, NAT, `sdkconfig`/`sdkconfig.defaults`, `netif_hooks.c`, logika STA, atau file inti Martin lainnya.

### File baru
- `include/heap_watch.h`, `main/heap_watch.c` – timer 1 detik (esp_timer) yang membaca heap bebas dan minimum sejak boot.
  - Event RAM rendah: `LOW_FREE` (heap bebas di bawah ambang, histeresis +8 KB) dan `DIP` (minimum baru di bawah ambang yang terjadi di antara dua tick). Log paling sering 1x per 10 detik.
  - Event terakhir disimpan di RTC_NOINIT dengan checksum FNV. Data ini bertahan setelah restart software/panic/watchdog/brownout, dan hilang saat listrik dicabut.
  - Callback alokasi gagal (`heap_caps_register_failed_alloc_callback`, IRAM, counter atomik). Permintaan PSRAM dihitung terpisah karena board ini tidak punya PSRAM.
  - Sesi uji RAM memakai monitor minimum lokal IDF (`heap_caps_monitor_local_minimum_free_size_start/stop`). Sesi hanya aktif atas perintah user, berhenti otomatis setelah 24 jam, dan ditolak kalau heap < 8 KB. Akses dilindungi mutex, dan timer melewati tick kalau mutex sedang dipakai.
  - Ambang disimpan di NVS `heap_low_kb` (8–100 KB, default 30).
- `tools/csv_logger/csv_logger.py`, `README.md` – logger CSV di HP/PC (Termux), memakai library standar saja.
- `tools/dash_test/test_stage2a.py` – tes Playwright untuk semua tombol Tahap 2A.

### Perubahan di file Tahap 1 (bukan file Martin)
- `main/sys_health.c`: perbaikan bug CPU pada wrap 2^32 µs (71,6 menit). Selisih dihitung unsigned, `s_prev_total != 0 && dt != 0`. `min_free_heap` diambil dari `heap_watch_boot_min()` supaya tetap benar selama sesi uji. `heap_watch_init()` dipanggil dari `sys_health_init()`.
- `components/http_server/dash_api.c`: objek `hw` di `/api/status`; `POST /api/heaptest` (start/stop); `GET /api/ramcheck` (hanya memeriksa, `freed` selalu 0); `heap_low_kb` di `/api/settings`.
- `components/http_server/http_internal.h`: `DASH_API_URI_COUNT` 12.
- `components/http_server/www/dash.html`: kartu Pemantauan RAM Rendah, Sesi Uji RAM, Periksa RAM (pengganti "Bersihkan RAM" sesuai persetujuan), dan Rekam CSV (di browser). CSS nilai `.kv` diubah dari `word-break:break-all` ke `overflow-wrap:break-word`, supaya kata tidak terpotong di tengah.
- `main/CMakeLists.txt`: tambah `heap_watch.c`.
- `CMakeLists.txt`: versi `2.4.23-mod.2a`.
- `tools/dash_test/mock_server.py`: endpoint baru untuk tes.

### Dampak ukuran (full clean build ESP-IDF 5.5.4, 0 warning)
- App: 0x155350 = 1.397.584 B (Tahap 1: 1.389.216 B, +8.368 B), sisa slot OTA 0x2acb0 (11%).
- IRAM: 116.471 B (88,86%, sisa 14.601 B), +88 B dibanding Tahap 1.
- DRAM statis: 49.504 B, +200 B. RTC slow noinit: 72 B.
- RAM runtime tambahan (perkiraan dari kode, belum diukur di hardware): esp_timer 1 detik tanpa task baru, mutex sekitar 100 B.

### Keterbatasan yang diketahui
- Tanpa sesi uji, lonjakan singkat (< 1 detik) yang tidak menembus minimum sejak boot tidak tertangkap. Sesi uji menutup celah ini.
- Selama sesi uji, perintah console `heap` Martin menampilkan minimum sesi, bukan minimum sejak boot. Dashboard tetap menampilkan keduanya dengan benar.
- Rekam CSV di browser bisa melambat kalau tab berada di latar belakang atau layar mati. Untuk rekaman panjang, pakai `csv_logger.py`.
- Satu sesi login (desain Martin): logger CSV dan browser saling menggantikan.

### Belum dikerjakan (tahap berikut)
2 Internet Sharing ON/OFF live, 3 speed limit per client, 4 smart roaming, 5 auto restart + anti boot-loop, 6 tab Clients/WiFi di /dash, 7 optimasi RAM.
Tahap 2B (speed limit), 2C (batas waktu), 2D (roaming): baru audit, belum ada izin implementasi.
