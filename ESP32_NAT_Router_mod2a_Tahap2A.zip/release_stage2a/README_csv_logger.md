# Logger CSV ESP32 NAT Router

Script ini mengambil `/api/status` dari router secara berkala lalu menyimpannya ke file CSV di HP atau PC. ESP32 tidak menyimpan apa pun ke flash, jadi tidak ada beban tulis ke flash dan tidak ada pemakaian RAM tambahan di ESP32.

Script hanya memakai library standar Python 3, tanpa `pip install`.

## Instalasi di Android (Termux)

1. Pasang Termux dari F-Droid.
2. Jalankan `pkg install python`.
3. Salin `csv_logger.py` ke HP, misalnya ke `~/csv_logger.py`.
4. Kalau file CSV ingin bisa dibuka dari aplikasi lain, jalankan `termux-setup-storage` lalu simpan ke `~/storage/downloads/`.

## Pemakaian

HP atau PC harus tersambung ke WiFi ESP32.

```
python3 csv_logger.py                       # minta password, interval 10 detik
python3 csv_logger.py --interval 30         # tiap 30 detik (minimal 5)
python3 csv_logger.py --count 120           # berhenti setelah 120 sampel
python3 csv_logger.py --out ~/storage/downloads/uji.csv
ESP_PW=passwordlo python3 csv_logger.py     # password lewat environment
```

Untuk berhenti, tekan Ctrl+C. Data yang sudah terekam tetap tersimpan, karena setiap baris langsung ditulis ke file.

## Kolom

`waktu_perangkat` adalah jam HP/PC. Kolom heap dalam byte. `heap_min_sesi` hanya terisi kalau Sesi Uji RAM sedang berjalan. `suhu_raw_F` adalah nilai mentah sensor die (bukan suhu casing), dan `suhu_status` menunjukkan apakah nilainya valid. Kolom `catatan` berisi `restart terdeteksi` kalau uptime ESP32 mundur, atau `tidak terjangkau` kalau router tidak menjawab.

## Batasan

- Firmware Martin hanya punya satu sesi login. Kalau script login, sesi browser di /dash akan terganti, dan sebaliknya.
- Secara default script berhenti kalau sesinya diambil alih (HTTP 401). Pakai `--relogin` kalau ingin script login ulang otomatis, dengan jeda minimal 60 detik. Akibatnya, browser akan ter-logout.
- Interval minimal 5 detik supaya tidak membebani httpd ESP32.
- Penurunan heap yang lebih singkat dari interval tidak terlihat di CSV. Untuk itu, pakai kolom `heap_min_boot`/`heap_min_sesi` dan event RAM rendah di dashboard, yang dicek tiap 1 detik di ESP32.
