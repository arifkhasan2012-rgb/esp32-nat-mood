#!/usr/bin/env python3
"""[MOD 2A] Logger CSV untuk ESP32 NAT Router (dashboard /dash).

Membaca /api/status secara berkala dan menulis satu baris CSV per sampel.
Hanya memakai pustaka standar Python 3 (jalan di PC maupun Termux Android).

Contoh:
    python3 csv_logger.py                       # 192.168.4.1, tiap 10 detik
    python3 csv_logger.py --interval 5 --out uji_speedtest.csv
    ESP_PW=rahasia python3 csv_logger.py --relogin

PENTING: firmware Martin hanya punya SATU sesi login. Kalau script ini login,
sesi dashboard di browser akan habis (dan sebaliknya). Default-nya script
berhenti ketika sesinya diambil alih; pakai --relogin hanya kalau lo tidak
sedang membuka dashboard.
"""
import argparse
import csv
import getpass
import http.cookiejar
import json
import os
import sys
import time
import urllib.error
import urllib.request

COLUMNS = [
    "waktu_perangkat", "uptime_s", "heap_bebas", "heap_internal", "heap_min_boot",
    "heap_min_sesi", "blok_terbesar", "frag_pct", "alokasi_gagal", "ram_rendah",
    "cpu0_pct", "cpu1_pct", "suhu_raw_F", "suhu_status", "rssi_dbm", "kanal", "bssid",
    "client", "byte_up", "byte_down", "nat_aktif", "catatan",
]
MIN_INTERVAL = 5
RELOGIN_GAP_S = 60


class SessionLost(Exception):
    pass


class Client:
    def __init__(self, host, timeout):
        self.base = "http://" + host
        self.timeout = timeout
        self.jar = http.cookiejar.CookieJar()
        self.opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.jar))

    def _req(self, path, body=None):
        headers = {"X-Requested-With": "dash"}
        data = None
        if body is not None:
            data = json.dumps(body).encode()
            headers["Content-Type"] = "application/json"
        req = urllib.request.Request(self.base + path, data=data, headers=headers)
        try:
            with self.opener.open(req, timeout=self.timeout) as r:
                return r.status, json.loads(r.read().decode() or "{}")
        except urllib.error.HTTPError as e:
            try:
                payload = json.loads(e.read().decode() or "{}")
            except ValueError:
                payload = {}
            return e.code, payload

    def login(self, password):
        code, j = self._req("/api/login", {"password": password})
        if code == 200 and j.get("ok"):
            return
        if code == 429:
            raise RuntimeError("Login diblokir sementara (terlalu banyak percobaan), "
                               "coba lagi dalam %s detik" % j.get("retry_after", "?"))
        if j.get("error") == "wrong_password":
            raise RuntimeError("Password salah")
        if j.get("error") == "password_not_set":
            raise RuntimeError("Password admin belum dibuat. Buat dulu di /dash")
        raise RuntimeError("Login gagal (HTTP %s): %s" % (code, j.get("message", j)))

    def status(self):
        code, j = self._req("/api/status")
        if code == 401:
            raise SessionLost()
        if code != 200 or not j.get("ok"):
            raise RuntimeError("HTTP %s: %s" % (code, j.get("message", j)))
        return j


def row_from_status(d, note):
    h = d.get("heap", {})
    w = d.get("wifi", {}) or {}
    hw = d.get("hw", {}) or {}
    sess = hw.get("sess", {}) or {}
    fail = hw.get("fail", {}) or {}
    cpu = d.get("cpu", [-1, -1])
    temp = d.get("temp", {})
    return [
        time.strftime("%Y-%m-%d %H:%M:%S"),
        d.get("uptime_s", ""), h.get("free", ""), h.get("internal", ""), h.get("min", ""),
        sess.get("min", "") if sess.get("active") else "",
        h.get("largest", ""), h.get("frag", ""),
        fail.get("n", 0) - fail.get("spiram", 0) if fail else "",
        1 if hw.get("low") else 0,
        "" if cpu[0] < 0 else cpu[0], "" if cpu[1] < 0 else cpu[1],
        temp.get("raw", ""), temp.get("state", ""),
        w.get("rssi", ""), w.get("channel", ""), w.get("bssid", ""),
        d.get("ap", {}).get("clients", ""),
        d.get("bytes", {}).get("sent", ""), d.get("bytes", {}).get("recv", ""),
        d.get("nat", {}).get("active", ""), note,
    ]


def empty_row(note):
    r = [""] * len(COLUMNS)
    r[0] = time.strftime("%Y-%m-%d %H:%M:%S")
    r[-1] = note
    return r


def main():
    ap = argparse.ArgumentParser(description="Logger CSV ESP32 NAT Router (/api/status)")
    ap.add_argument("--host", default="192.168.4.1", help="alamat router (default 192.168.4.1)")
    ap.add_argument("--interval", type=int, default=10, help="detik antar sampel (min 5, default 10)")
    ap.add_argument("--out", default=None, help="file CSV (default esp32_monitor_TANGGAL.csv)")
    ap.add_argument("--timeout", type=float, default=5.0, help="timeout HTTP dalam detik")
    ap.add_argument("--relogin", action="store_true",
                    help="login ulang otomatis kalau sesi habis (mengambil alih sesi browser)")
    ap.add_argument("--count", type=int, default=0, help="berhenti setelah N sampel (0 = terus)")
    a = ap.parse_args()

    if a.interval < MIN_INTERVAL:
        print("Interval minimal %d detik supaya tidak membebani ESP32." % MIN_INTERVAL, file=sys.stderr)
        return 2
    password = os.environ.get("ESP_PW") or getpass.getpass("Password router: ")
    out = a.out or time.strftime("esp32_monitor_%Y%m%d_%H%M.csv")
    cl = Client(a.host, a.timeout)
    try:
        cl.login(password)
    except (RuntimeError, OSError) as e:
        print("Gagal login: %s" % e, file=sys.stderr)
        return 1

    new_file = not os.path.exists(out) or os.path.getsize(out) == 0
    last_uptime = None
    last_login = time.time()
    n = 0
    print("Merekam ke %s tiap %d detik. Ctrl+C untuk berhenti." % (out, a.interval))
    with open(out, "a", newline="", encoding="utf-8") as f:
        wr = csv.writer(f)
        if new_file:
            wr.writerow(COLUMNS)
        try:
            while True:
                t0 = time.time()
                try:
                    d = cl.status()
                    note = ""
                    up = d.get("uptime_s")
                    if last_uptime is not None and up is not None and up < last_uptime:
                        note = "restart terdeteksi"
                    last_uptime = up
                    wr.writerow(row_from_status(d, note))
                    hw = d.get("hw", {})
                    print("\r%s heap %6s B  min %6s B  gagal %s  client %s   " % (
                        time.strftime("%H:%M:%S"), d["heap"]["free"], d["heap"]["min"],
                        hw.get("fail", {}).get("n", "?"), d["ap"]["clients"]), end="", flush=True)
                except SessionLost:
                    if not a.relogin:
                        wr.writerow(empty_row("sesi login habis/diambil alih"))
                        f.flush()
                        print("\nSesi login habis atau diambil alih (mis. dashboard dibuka). "
                              "Jalankan ulang, atau pakai --relogin.", file=sys.stderr)
                        return 3
                    if time.time() - last_login >= RELOGIN_GAP_S:
                        try:
                            cl.login(password)
                            last_login = time.time()
                            wr.writerow(empty_row("login ulang"))
                        except (RuntimeError, OSError) as e:
                            wr.writerow(empty_row("login ulang gagal: %s" % e))
                    else:
                        wr.writerow(empty_row("sesi habis, menunggu login ulang"))
                except (OSError, ValueError, RuntimeError) as e:
                    wr.writerow(empty_row("tidak terjangkau: %s" % e.__class__.__name__))
                    print("\r%s router tidak terjangkau (%s)        " % (
                        time.strftime("%H:%M:%S"), e.__class__.__name__), end="", flush=True)
                f.flush()
                n += 1
                if a.count and n >= a.count:
                    break
                time.sleep(max(0.0, a.interval - (time.time() - t0)))
        except KeyboardInterrupt:
            pass
    print("\nSelesai. %d sampel tersimpan di %s" % (n, out))
    return 0


if __name__ == "__main__":
    sys.exit(main())
