# Audit, Kelayakan & Rencana Tahap 2 — ESP32 NAT Router mod

Basis: firmware Martin v2.4.23 (commit 08da293) + Tahap 1 (commit 2b51d63, `2.4.23-mod.1`), ESP-IDF 5.5.4, ESP32 klasik, flash 4 MB.
Status dokumen: audit & rencana. **Tahap 2A (monitoring) sudah diimplementasikan** di branch `mod/stage2a-monitoring` (lihat `MOD_CHANGES.md`). Tahap 2B, 2C, dan 2D masih sebatas audit dan rencana, tanpa perubahan kode, menunggu persetujuan.
Keputusan 2C dari lo: waktu dihitung sejak perangkat terhubung ke WiFi ESP32, nilai 0 = tanpa batas, reset kuota manual dari dashboard, dan saat waktu habis hanya akses internet yang diblokir (DHCP dan dashboard 192.168.4.1 tetap jalan, tanpa deauth).

---

## 1. Ringkasan status fitur

| Fitur | Status sekarang | Kompleksitas | Risiko ke stabilitas | Menyentuh kode inti Martin? |
|---|---|---|---|---|
| M1. Tombol "Mulai sesi uji" (min heap lokal) | Belum tersedia | Rendah | Sangat rendah | Tidak |
| M2. Catat otomatis heap < 30 KB | Belum tersedia | Rendah | Sangat rendah | Tidak |
| M3. Penghitung alokasi gagal | Belum tersedia | Rendah | Rendah | Tidak |
| M4. Perbaikan bug CPU 71,6 menit | Bug terbukti (di kode Tahap 1, bukan kode Martin) | Sangat rendah | Sangat rendah | Tidak |
| M5. Logger CSV (PC/Termux) | Belum tersedia | Rendah | Nol (di luar firmware) | Tidak |
| Speed limit per perangkat | Belum tersedia | Sedang | Sedang | Ya — 2 titik panggil kecil di `netif_hooks.c` |
| Batas waktu per perangkat | Belum tersedia | Sedang | Sedang | Ya — titik panggil yang sama + event STA connect |
| Roaming antar AP "Jannet" (Open) | Belum tersedia di ESP32 klasik | Tinggi | Tinggi | Ya — logika koneksi STA |
| Tombol "Bersihkan RAM" | Tidak layak secara teknis (lihat §6) | — | — | — |

Urutan yang saya usulkan: **2A Monitoring → 2B Speed limit → 2C Batas waktu → 2D Roaming**. Tiap tahap di-build, diuji, dan diserahkan terpisah, supaya kalau ada masalah mudah dilacak.

---

## 2. Monitoring (prioritas pertama)

### Temuan API (dicek langsung di header ESP-IDF 5.5.4, `components/heap/include/esp_heap_caps.h`)
- `heap_caps_monitor_local_minimum_free_size_start()` / `_stop()` — tersedia (baris 258/268).
- `heap_caps_register_failed_alloc_callback()` — tersedia (baris 66). Berjalan tanpa `CONFIG_HEAP_USE_HOOKS`, jadi **tidak perlu mengubah sdkconfig**.
- `CONFIG_HEAP_ABORT_WHEN_ALLOCATION_FAILS` tidak aktif → alokasi gagal tidak membuat crash, cukup dihitung.

### M1. Sesi uji (minimum heap lokal)
- Tombol di /dash: "Mulai sesi uji" / "Akhiri sesi". Menampilkan minimum heap sejak sesi dimulai, terpisah dari minimum sejak boot (16 KB yang lo lihat).
- Dampak: hanya membaca statistik heap, tidak mengubah alokasi apa pun.
- Catatan jujur: ESP-IDF hanya punya satu monitor lokal global; kalau sesi dimulai ulang, nilai sesi lama hilang (nilai sejak boot tetap ada).

### M2. Pencatatan otomatis heap < 30 KB
- Sampler 10 detik yang sudah ada tidak cukup — penurunan heap akibat burst WiFi bisa terjadi hanya beberapa milidetik. Jadi yang dipantau adalah **nilai minimum** (bukan sekadar heap saat ini): kalau minimum turun di bawah 30 KB di antara dua sampel, firmware mencatat "heap sempat X KB antara uptime T1–T2" beserta heap saat itu, blok terbesar, jumlah klien, dan RSSI.
- Anti-spam: hanya dicatat sekali, aktif lagi setelah heap pulih di atas 40 KB (histeresis).
- Penyimpanan: event log RAM yang sudah ada + **satu rekaman terakhir di RTC no-init memory (~32 byte)** supaya tetap terbaca setelah restart software/watchdog (hilang kalau listrik dicabut). Tidak menulis ke flash, jadi tidak ada keausan flash.
- Ambang 30 KB bisa diatur dari /dash (disimpan di NVS, hanya ditulis saat lo mengubahnya).

### M3. Penghitung alokasi gagal
- Callback hanya menaikkan counter dan menyimpan ukuran + caps permintaan terakhir. Tidak ada logging/printf di dalam callback karena bisa dipanggil dari task WiFi/lwIP.
- Ini indikator paling jujur: heap rendah belum tentu masalah, tapi alokasi gagal = ada komponen yang benar-benar kekurangan memori.

### M4. Bug CPU 71,6 menit — bukti
Penyebab terbukti dari tiga fakta:
1. `sdkconfig`: `CONFIG_FREERTOS_RUN_TIME_COUNTER_TYPE_U32=y` dan `CONFIG_FREERTOS_RUN_TIME_STATS_USING_ESP_TIMER=y`.
2. ESP-IDF `portmacro.h` baris 517: `portGET_RUN_TIME_COUNTER_VALUE() = (uint32_t) esp_timer_get_time()` → counter mikrodetik 32-bit, kembali ke 0 setiap 2³² µs = **4294,97 detik = 71,58 menit**.
3. `main/sys_health.c` baris 107: `if (s_prev_total != 0 && total > s_prev_total)` — saat counter kembali ke 0, `total < s_prev_total` sehingga sampel dibuang dan CPU tampil "—" (nilai −1).

Simulasi logika yang sama persis (3 jam, sampel 10 detik, beban 20%): logika lama kehilangan sampel pada menit 71,7 dan 143,2; logika perbaikan 0 sampel salah.

Dampak bug: **kecil** — hanya 1 sampel CPU hilang setiap 71,6 menit, tidak memengaruhi jaringan. Ini kesalahan di kode Tahap 1 saya, bukan kode Martin.
Perbaikan: hapus syarat `total > s_prev_total`, pakai pengurangan unsigned 32-bit (otomatis benar saat wrap karena jarak sampel 10 detik jauh di bawah 71 menit). Tidak mengubah sdkconfig (opsi ganti ke counter 64-bit sengaja tidak dipakai karena mengubah konfigurasi).

### M5. Logger CSV
- Script Python `tools/csv_logger.py`, jalan di PC atau Termux (Android), membaca `/api/status` setiap 10 detik (minimal 5 detik), login dengan password router, menulis CSV: waktu, uptime, heap bebas, min heap, min sesi, blok terbesar, alokasi gagal, CPU0/1, suhu mentah, RSSI, kanal, jumlah klien, byte up/down.
- Tidak ada perubahan firmware. Beban ke ESP32 sama dengan satu tab dashboard yang terbuka.

---

## 3. Speed limit per perangkat

### Jawaban pertanyaan lo
- **Bisa beda per perangkat?** Ya, per MAC address, upload dan download terpisah, satuan Kbps (dashboard bisa input Mbps lalu dikonversi).
- **Independen?** Ya. Tiap perangkat punya "ember token" sendiri; limit perangkat A tidak memengaruhi B.
- **0 = tanpa batas.**
- **Kapan berlaku?** Langsung setelah disimpan, tanpa restart, tanpa memutus WiFi klien.

### Cara kerja (sudah dicek di source)
Martin sudah punya hook di jalur AP (`main/netif_hooks.c`):
- `ap_netif_input_hook` (baris 502) = paket dari klien = **upload**, MAC sumber.
- `ap_netif_linkoutput_hook` (baris 582) = paket ke klien = **download**, MAC tujuan.
Keduanya berada tepat di jalur forwarding NAT, jadi limit benar-benar berlaku pada lalu lintas internet klien, bukan sekadar angka di dashboard.

Rencana: tambahkan **satu panggilan fungsi** di masing-masing hook ke modul baru `main/rate_limit.c`. Metode token bucket "policing" (paket di atas kuota dibuang, tidak diantrekan) → **tidak menambah buffer/RAM untuk paket**. Pola buang-paket mengikuti pola ACL Martin yang sudah ada (input: `pbuf_free`, linkoutput: kembalikan `ERR_OK`).
Upload hanya diproses di jalur input, download hanya di jalur output → tiap ember hanya disentuh satu konteks, tidak perlu mutex di jalur paket.

### Batasan jujur
- Download dibatasi saat paket **sudah sampai** di ESP32 dari upstream. TCP akan menyesuaikan kecepatan, tapi UDP (game, video call) tetap memakan bandwidth upstream walau dibuang.
- Akurasi realistis ±10–20% untuk TCP (pola naik-turun khas TCP). Akan dibuktikan dengan speed test nyata, bukan angka dashboard.
- Limit di atas kemampuan nyata ESP32 sebagai repeater tidak ada artinya.
- Biaya: kode di IRAM sekitar 1–2 KB (sisa IRAM 14,7 KB), RAM statis < 1 KB untuk 10 entri.
- Perangkat dengan MAC acak (Android/iOS "Private MAC") akan dianggap perangkat baru jika MAC-nya berubah.

---

## 4. Batas waktu per perangkat

### Rancangan
- Per MAC: kuota menit (contoh A = 120, B = 300). **0 = tanpa batas, bukan 0 menit.** Di UI, 0 tampil sebagai "Tanpa batas", dan field kosong juga diperlakukan tanpa batas. Nilai valid 1–1440 menit.
- Saat habis: **akses internet perangkat itu dihentikan otomatis** dengan membuang paketnya di hook input yang sama (kecuali lalu lintas ke 192.168.4.1 dan DHCP, supaya perangkat tetap bisa membuka dashboard/halaman info). WiFi tidak diputus paksa → tidak ada siklus connect-deauth berulang.
  Alternatif (pakai fitur blokir Martin yang sudah ada, deauth) bisa dipilih, tapi menurut gw kurang ramah karena HP akan terus mencoba konek.
- Individu per klien, berjalan independen.

### Keputusan yang perlu dari lo
1. Waktu dihitung saat **terhubung ke WiFi** (lebih sederhana dan dapat diprediksi), atau hanya saat **ada lalu lintas** (lebih adil, tapi "aktif" perlu didefinisikan)? Usulan: terhubung.
2. Reset kuota: manual dari dashboard saja, atau **otomatis tiap tengah malam**? Reset harian butuh jam dari SNTP (Martin sudah punya SNTP + zona waktu); jika jam belum sinkron, reset ditunda, tidak diasumsikan.
3. Sisa waktu disimpan ke NVS tiap 5 menit supaya tidak hilang saat restart (paling banyak hilang 5 menit hitungan). Beban tulis flash kecil, NVS punya wear-leveling.

---

## 5. Roaming antar AP Open "Jannet"

### Kondisi firmware saat ini (dicek di source)
- Konfigurasi STA di `esp32_nat_router.c` baris 1085: `wifi_config_t wifi_config = { 0 }` → `scan_method = WIFI_FAST_SCAN` dan `threshold.authmode = OPEN`.
- Menurut header ESP-IDF, FAST_SCAN = "scan berhenti setelah menemukan AP dengan SSID yang cocok". Artinya ESP32 **menyambung ke "Jannet" pertama yang ditemukan, belum tentu yang terkuat**.
- Saat sudah tersambung, tidak ada perpindahan walau sinyal melemah; pindah hanya terjadi setelah koneksi putus total, lewat timer reconnect backoff.
- Pemilihan BSSID per band hanya untuk chip 5 GHz (C5), tidak aktif di ESP32 klasik.
- Roaming app bawaan ESP-IDF (`CONFIG_ESP_WIFI_ENABLE_ROAMING_APP`) berlabel **Experimental** dan butuh `IDF_EXPERIMENTAL_FEATURES` → **tidak saya rekomendasikan** untuk firmware yang mengutamakan stabilitas. 802.11k/v juga butuh dukungan AP, yang hampir pasti tidak ada di AP RT/RW Net.

### Jawaban pertanyaan lo
- **Deteksi AP lebih kuat & pindah otomatis tanpa restart?** Bisa dikembangkan: event `WIFI_EVENT_STA_BSS_RSSI_LOW` (via `esp_wifi_set_rssi_threshold`) + scan berkala → pilih BSSID "Jannet" lain yang lebih kuat minimal X dB (histeresis, mis. 8 dB, dan jeda minimal beberapa menit antar pindah) → `esp_wifi_set_config` dengan `bssid_set` → putus-sambung ke BSSID itu. Tanpa restart ESP32.
- **NAT dan klien tetap jalan?** Handler `IP_EVENT_STA_GOT_IP` Martin (baris ~712) sudah mengaktifkan ulang NAPT, port forward, dan DNS setiap dapat IP — jalur ini dipakai ulang tanpa diubah. Klien tetap terhubung ke ESP32. **Tetapi** ada jeda internet ±1–3 detik saat pindah, dan kalau IP upstream berubah, koneksi TCP yang sedang berjalan (download, video call) akan putus lalu aplikasi menyambung ulang. Ini batasan NAT, bukan bug.
- **Kanal berbeda?** ESP32 hanya punya satu radio, jadi SoftAP wajib ikut kanal STA. Dokumentasi ESP-IDF 5.5.4 (`docs/en/api-guides/wifi.rst`) menyatakan SoftAP akan mengirim **Channel Switch Announcement (CSA)** ke klien; klien yang mendukung CSA pindah tanpa putus, yang tidak mendukung akan putus lalu konek ulang sendiri. Perlu diuji di HP lo.
- **Scan saat tersambung?** Bisa (background scan); menurut dokumentasi IDF, driver kembali ke kanal utama 30 ms di antara kanal. Efeknya latensi/throughput klien turun sesaat selama ±1,5–2 detik scan. Karena itu scan hanya dilakukan saat sinyal lemah atau dengan interval jarang (mis. 5 menit), bukan terus-menerus.

### Risiko khusus jaringan Open
- Jaringan Open tidak punya autentikasi, jadi **siapa pun bisa memancarkan "Jannet"** dan ESP32 tidak bisa membedakan AP asli dan palsu dari namanya. Sesuai keputusan opsi C sebelumnya: default otomatis, plus opsi "hanya BSSID terpercaya" — BSSID masuk daftar setelah terbukti punya internet (cek HTTP 204), dan lo bisa mengunci daftar itu dari dashboard.
- Jannet memakai captive portal. Detailnya ada di subbagian berikut.

### Temuan Jannet: captive portal & sesi saat pindah AP (diperbarui setelah klarifikasi lo)

**A. Pengamatan lo (belum gw buktikan secara teknis)**
- Jannet adalah layanan RT/RW Net. WiFi-nya Open, tanpa password WPA, dan memakai captive portal. Pengguna login dengan username + password, sedangkan akun pemilik WiFi cukup dengan username.
- ESP32 lo sudah login ke Jannet.
- Saat ESP32 pindah ke AP tetangga dengan SSID dan provider Jannet yang sama, tidak ada permintaan login ulang, dan sesi tetap berjalan.
- Login ulang baru diperlukan kalau sesi diakhiri lewat endpoint `http://172.168.60.1/logout`.

**B. Yang terbukti (dari source dan dokumentasi)**
- Firmware Martin tidak punya logika captive portal sama sekali: tidak ada login otomatis dan tidak ada pemanggilan URL portal. Login Jannet dilakukan dari perangkat lo, dan portal melihatnya datang dari IP/MAC STA ESP32 karena lalu lintas klien di-NAT.
- MAC STA ESP32 tetap sama di semua AP. Martin hanya memasang MAC sekali saat start (`esp32_nat_router.c` baris ~1146: MAC bawaan, atau MAC kustom dari perintah console `set_mac` yang disimpan di NVS), dan tidak mengubahnya per AP. MAC inilah identitas lapisan 2 yang bisa dilihat portal. Catatan: kalau lo pernah memakai `set_mac` lalu mengubahnya, portal akan melihat perangkat baru.
- Saat koneksi STA tersambung ulang, Martin meminta DHCP lagi. Handler `IP_EVENT_STA_GOT_IP` mengaktifkan ulang NAPT, port forward, dan DNS, sehingga jalur NAT tetap pulih walaupun IP berubah.
- Gw **tidak** mengakses `172.168.60.1` (termasuk `/logout`) dalam bentuk apa pun, dan rancangan roaming tidak akan menyentuhnya.
- Catatan alamat: `172.168.60.1` berada **di luar** rentang privat RFC 1918 (`172.16.0.0/12` = 172.16–172.31). Kemungkinan besar operator memakainya sebagai alamat internal walau secara resmi itu blok publik. Ini tidak memengaruhi fungsi, tapi berarti firmware tidak boleh menebak "IP privat = gateway lokal" untuk alamat ini.

**C. Mekanisme yang paling mungkin (hipotesis, wajib diverifikasi, bukan diasumsikan)**
- Kemungkinan besar semua AP Jannet hanya berfungsi sebagai bridge/AP ke satu jaringan lapisan 2 atau backhaul yang sama, dengan satu server hotspot (pola umum RT/RW Net: MikroTik Hotspot) yang memegang gateway dan DHCP `172.168.60.x`.
- Server hotspot seperti ini biasanya mengikat sesi ke MAC dan/atau IP klien, bukan ke AP. Kalau ESP32 pindah AP tapi tetap di L2 yang sama, server tetap melihat MAC yang sama, DHCP kemungkinan memberi IP yang sama, dan sesi dianggap tidak putus. Ini cocok dengan pengamatan lo.
- Faktor yang **bisa** membuat sesi putus walau SSID sama:
  1. AP tetangga tersambung ke server hotspot atau subnet lain (beda gateway/DHCP).
  2. IP berubah dan server mengikat sesi ke IP.
  3. Idle-timeout atau batas sesi di server habis selama jeda pindah.
  4. Ada AP dengan nama "Jannet" yang bukan milik operator (jaringan Open bisa ditiru siapa pun).
- Jadi kesimpulannya: **jangan menganggap semua AP Jannet otomatis berbagi sesi.** Yang bisa diharapkan hanya untuk AP yang terbukti berada di belakang gateway yang sama.

**D. Cara verifikasi nanti (tanpa logout dan tanpa login otomatis)**, saat 2D disetujui:
1. Sebelum dan sesudah pindah AP, catat BSSID, IP STA, gateway IP, MAC gateway (dari tabel ARP lwIP), dan DNS dari DHCP. Kalau gateway IP+MAC sama, itu bukti kuat bahwa AP-AP tersebut berada di jaringan yang sama.
2. Cek internet ringan (HTTP 204 ke endpoint generate_204) setelah pindah. Kalau jawabannya 204, sesi masih berlaku. Kalau ada redirect/HTML portal, berarti butuh login, dan ESP32 hanya **melaporkan** di dashboard. Tidak ada login ulang otomatis.
3. Opsional: bandingkan IP publik sebelum dan sesudah pindah, lewat permintaan manual dari dashboard, bukan otomatis.
4. BSSID baru masuk daftar "terpercaya" (opsi C) hanya kalau langkah 1 dan 2 lolos. Ini sekaligus menyaring AP palsu atau AP di belakang server lain.

**E. Dampak ke rancangan 2D**
- Roaming tetap **OFF secara default**.
- Tidak ada login ulang otomatis dan tidak ada akses ke endpoint logout.
- Kalau setelah pindah cek internet mendeteksi portal, opsi aman yang diusulkan adalah kembali ke BSSID sebelumnya yang terbukti punya internet, lalu menandai BSSID baru sebagai "butuh login". Detailnya didiskusikan saat 2D disetujui.

### Perubahan yang butuh persetujuan khusus
Roaming harus menyentuh logika koneksi STA Martin. Usulan: modul terpisah `main/roam.c`, aktif hanya jika opsi roaming dinyalakan (default **mati**), sehingga perilaku Martin tetap sama persis ketika fitur dimatikan. Opsi tambahan "pilih AP terkuat saat konek awal" (ganti FAST_SCAN → ALL_CHANNEL_SCAN + urut sinyal) juga mengubah konfigurasi bawaan Martin, jadi hanya aktif jika roaming dinyalakan.

---

## 6. Optimasi RAM & tombol "Bersihkan RAM"

### Hasil audit
- ESP-IDF memakai C tanpa garbage collector. RAM "terpakai" artinya sedang dimiliki oleh suatu komponen; memori yang sudah tidak dipakai **sudah langsung kembali ke heap** saat pemiliknya memanggil `free()`. Tidak ada "sampah" yang menumpuk untuk dibersihkan.
- Heap juga tidak bisa didefragmentasi (pointer di C tidak bisa dipindah). Fragmentasi lo saat ini 5% — sudah rendah.
- Saya periksa semua alokasi besar di source:
  - Buffer PCAP 32 KB: Martin **sudah** mengalokasikannya hanya saat ada klien capture dan membebaskannya setelah sesi selesai (`pcap_capture.c` baris 165 & 207).
  - Buffer remote console 10 KB: hanya selama ada sesi remote console, lalu dibebaskan saat sesi berakhir (baris 641/724).
  - Hasil scan WiFi, halaman web, buffer API: semuanya dialokasikan per-permintaan lalu dibebaskan.
  - Buffer WiFi dinamis (penyebab min heap 16 KB), tabel NAPT 512 entri, socket lwIP, stack task: **sedang dipakai** driver/NAT/task — tidak boleh disentuh.
- Kesimpulan: **tidak ada alokasi yang aman dan bermakna untuk dibebaskan secara manual.** Tombol "Bersihkan RAM" yang "berhasil" hanya akan menjadi tombol dekorasi atau malah berbahaya.

### Usulan pengganti (jujur, berfungsi)
Panel "Status RAM" di /dash dengan tombol **"Periksa RAM"** yang benar-benar melakukan pengecekan: membaca heap bebas, blok terbesar, fragmentasi, minimum sesi, alokasi gagal, dan stack tersisa tiap task, lalu menampilkan kesimpulan, misalnya "RAM sudah optimal — tidak ada alokasi yang aman untuk dibebaskan" atau peringatan spesifik ("blok terbesar < 8 KB", "ada 3 alokasi gagal"). Tidak ada angka yang dimanipulasi.

Penghematan nyata hanya mungkin dengan **mengubah konfigurasi** (jumlah buffer WiFi, ukuran stack, tabel NAPT, mematikan layanan yang tidak dipakai). Itu termasuk yang lo larang ubah, jadi tidak saya sentuh. Kalau nanti data logger CSV menunjukkan heap benar-benar kritis, baru kita diskusikan dengan angka nyata.

---

## 7. Pemisahan, kompatibilitas & backup

### File yang direncanakan
| Tahap | File baru | File diubah (minimal, ditandai `[MOD]`) |
|---|---|---|
| 2A | `main/heap_watch.c`, `include/heap_watch.h`, `tools/csv_logger.py` | `main/sys_health.c` (fix CPU, panggil heap_watch — kode Tahap 1), `components/http_server/dash_api.c` + `www/dash.html` (kode Tahap 1), `main/CMakeLists.txt` (daftar file) |
| 2B | `main/rate_limit.c`, `include/rate_limit.h` | `main/netif_hooks.c` (2 baris panggilan), dash API + UI |
| 2C | `main/time_quota.c`, `include/time_quota.h` | `main/netif_hooks.c` (pakai titik panggil 2B), event STA connect/disconnect di `esp32_nat_router.c`, dash API + UI |
| 2D | `main/roam.c`, `include/roam.h` | `esp32_nat_router.c` (panggil roam saat diaktifkan), dash API + UI |

Tahap 2A **sama sekali tidak menyentuh** buffer WiFi, NAT, sdkconfig, atau kode Martin.

### Kompatibilitas
- Semua API yang direncanakan sudah dicek ada di header ESP-IDF 5.5.4 lokal.
- Tidak ada perubahan partisi; app sekarang 1.389.216 B dari slot 1.536 KB (sisa ±179 KB). Tambahan diperkirakan < 20 KB untuk semua tahap. Ukuran nyata akan dilaporkan dari hasil build.
- Build wajib 0 warning baru, dicek ukuran IRAM/DRAM tiap tahap.

### Backup sebelum modifikasi
1. Git tag `backup/pre-tahap2` di commit 2b51d63 + branch baru `mod/stage2-monitoring` (tiap tahap branch/commit sendiri).
2. Arsip `backup/esp32_nat_router_pre_tahap2.tar.gz` dan salinan `release_stage1/` (BIN yang sedang lo pakai) dengan SHA256.

### Verifikasi yang akan dilaporkan
Build ESP-IDF 5.5.4, ukuran per region, alamat flash dari `flasher_args.json`, tes mock dashboard di browser headless, simulasi host untuk logika (token bucket, kuota waktu, wrap CPU). **Pengujian hardware (speed test nyata, roaming nyata) tetap harus lo lakukan**; saya sertakan checklist dan tidak akan mengklaim fitur lolos sebelum ada hasil uji dari lo.

---

## 8. Yang perlu lo putuskan
1. Setujui Tahap 2A (monitoring M1–M5) dikerjakan dulu?
2. Tombol "Bersihkan RAM" diganti "Periksa RAM" seperti §6?
3. Batas waktu: dihitung saat terhubung atau saat ada traffic? Reset manual atau otomatis tengah malam? Saat habis: blokir internet saja (usulan) atau deauth?
4. Jannet pakai halaman login/voucher atau langsung internet? AP tetangga itu dari RT/RW Net yang sama?
5. Izin menyentuh `netif_hooks.c` (2B/2C) dan logika STA (2D), dengan roaming default mati?
