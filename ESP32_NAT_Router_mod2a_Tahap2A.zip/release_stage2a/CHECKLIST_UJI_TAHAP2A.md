# Checklist Uji Hardware – Tahap 2A (v2.4.23-mod.2a)

Semua hasil di bawah perlu diuji di ESP32 lo dengan traffic nyata. Sampai checklist ini terisi, status firmware adalah **build sukses + lulus tes host/mock, belum teruji di hardware**.

## 0. Flash

- [ ] Upgrade dari Tahap 1: flash 4 file terpisah (0x1000, 0x8000, 0xF000, 0x20000) **tanpa** "Erase flash". Setting (SSID uplink, password AP, password admin) harus tetap ada.
- [ ] Atau flash `esp32_nat_router_MERGED_0x0.bin` di 0x0. Cara ini menghapus semua setting, jadi router kembali ke default.
- [ ] Buka `http://192.168.4.1/dash`, lalu login. Di Ringkasan, baris Firmware harus tampil `2.4.23-mod.2a`.

## 1. Regresi (fungsi lama tetap jalan)

- [ ] HP klien dapat internet lewat ESP32 (buka web, YouTube).
- [ ] Halaman klasik Martin (`http://192.168.4.1/`) masih bisa dibuka dan login.
- [ ] Port forward atau setting lain yang lo pakai masih berfungsi.
- [ ] Tab Ringkasan, Log, dan Admin di /dash masih normal.

## 2. Sesi Uji RAM + speed test (wajib traffic nyata)

1. Di Sistem → Sesi Uji RAM, klik **Mulai sesi uji**. Status harus "Berjalan".
2. Jalankan speed test (speedtest.net atau fast.com) di 1 HP, lalu di 2–3 HP sekaligus kalau ada.
3. Klik **Akhiri sesi**.

- [ ] Hasil Minimum selama sesi: ______ KB
- [ ] Minimum sejak boot: ______ KB
- [ ] Alokasi gagal selama sesi: ______ (harapannya 0)
- [ ] Kecepatan speed test: down ______ / up ______ Mbps (bandingkan dengan Tahap 1; seharusnya tidak turun)
- [ ] Klik Mulai dua kali berturut-turut. Klik kedua harus ditolak dengan pesan, bukan error aneh.
- [ ] Opsional (serial console): selama sesi aktif, `heap` menampilkan minimum sesi. Setelah diakhiri, kembali ke minimum sejak boot.

## 3. Event RAM rendah

- [ ] Ubah ambang ke **100** KB lalu Simpan. Karena heap bebas sekitar 100 KB, dalam beberapa detik status harus "Di bawah ambang", dan Event RAM rendah bertambah. Ini cara aman memicu event tanpa membebani ESP32.
- [ ] Tab Log menampilkan catatan event RAM rendah.
- [ ] Coba isi ambang **5**. Harus ditolak (rentang 8–100).
- [ ] Kembalikan ambang ke **30**, lalu Simpan.
- [ ] Setelah restart, ambang tetap 30 (tersimpan di NVS).

## 4. Catatan bertahan setelah restart

- [ ] Setelah ada event (langkah 3), klik Restart di tab Admin. Setelah hidup lagi, "Sebelum restart terakhir" harus berisi event tadi.
- [ ] Cabut listrik ±5 detik, lalu nyalakan. "Sebelum restart terakhir" harus "Tidak ada catatan" (RTC RAM hilang saat listrik mati; ini memang perilaku chip).

## 5. Perbaikan CPU 71,6 menit

- [ ] Biarkan ESP32 menyala lebih dari 75 menit tanpa restart (sebaiknya sampai 145 menit).
- [ ] Rekam CSV (langkah 7 atau 8) di sekitar uptime 4.290–4.300 detik dan 8.585–8.595 detik. Kolom `cpu0_pct` dan `cpu1_pct` harus tetap terisi dan wajar, tidak kosong dan tidak melonjak ke 0/100.

## 6. Periksa RAM

- [ ] Catat RAM bebas, lalu klik **Periksa RAM**. Hasilnya harus menampilkan "0 byte" yang dibebaskan beserta daftar pemeriksaan.
- [ ] RAM bebas sebelum dan sesudah klik relatif sama (tombol ini tidak membebaskan apa pun).
- [ ] Internet klien tidak terganggu saat tombol diklik.

## 7. Rekam CSV di browser

- [ ] Pilih interval 5 detik, klik Mulai rekam, biarkan ±2 menit (layar tetap menyala), lalu Hentikan.
- [ ] Klik Unduh CSV. File harus bisa dibuka di spreadsheet dan kolomnya rapi.
- [ ] Klik Hapus data. Baris terekam harus 0.

## 8. Logger CSV di Termux

- [ ] `pkg install python`, lalu `python3 csv_logger.py --interval 10 --count 30`.
- [ ] File CSV terbentuk dan berisi 30 baris.
- [ ] Saat logger jalan, login di /dash dari browser. Logger harus berhenti dengan pesan sesi diambil alih (tanpa `--relogin`).

## 9. Stabilitas

- [ ] Jalan minimal 2 jam dengan pemakaian normal, tanpa restart sendiri (uptime terus naik).
- [ ] Alokasi gagal (sejak boot) tetap 0, atau catat nilainya: ______
- [ ] Minimum sejak boot setelah 2 jam: ______ KB

## Laporan balik ke gw

Kirim angka-angka di atas, screenshot tab Sistem, dan file CSV kalau ada masalah.
